#include <iostream>
using namespace std;

class Solution {
public:
    int addDigits(int num) {

        if (num == 0) {
            return 0;
        }

        return 1 + (num - 1) % 9;
    }
};

int main() {
    Solution obj;

    int num;
    cin >> num;

    cout << obj.addDigits(num);

    return 0;
}