#include <iostream>
using namespace std;

class Solution {
public:
    int addDigits(int num) {

        while (num >= 10) {
            int sum = 0;

            while (num > 0) {
                sum = sum + (num % 10);
                num = num / 10;
            }

            num = sum;
        }

        return num;
    }
};

int main() {
    Solution obj;

    int num;
    cin >> num;

    cout << obj.addDigits(num);

    return 0;
}