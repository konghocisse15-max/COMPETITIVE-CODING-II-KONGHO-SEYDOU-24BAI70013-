#include <iostream>
using namespace std;

class Solution {
public:
    int climbStairs(int n) {
        if (n <= 2) {
            return n;
        }

        return climbStairs(n - 1) + climbStairs(n - 2);
    }
};

int main() {
    Solution obj;

    int n;
    cin >> n;

    cout << obj.climbStairs(n);

    return 0;
}