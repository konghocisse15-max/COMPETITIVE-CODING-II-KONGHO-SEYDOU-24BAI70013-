#include <iostream>
#include <vector>
#include <algorithm>
#include <climits>
#include <cmath>
using namespace std;

class Solution {
public:
    int minCost(vector<int>& height, int k) {
        int n = height.size();

        vector<int> dp(n, 0);

        for (int i = 1; i < n; i++) {
            int best = INT_MAX;

            for (int j = max(0, i - k); j < i; j++) {
                int cost = dp[j] + abs(height[i] - height[j]);

                best = min(best, cost);
            }

            dp[i] = best;
        }

        return dp[n - 1];
    }
};

int main() {
    Solution obj;

    int n, k;
    cin >> n;

    vector<int> height(n);

    for (int i = 0; i < n; i++) {
        cin >> height[i];
    }

    cin >> k;

    cout << obj.minCost(height, k);

    return 0;
}