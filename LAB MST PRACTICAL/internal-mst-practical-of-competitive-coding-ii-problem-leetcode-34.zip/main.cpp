#include <iostream>
#include <vector>

using namespace std;

class Solution {
public:
    vector<int> searchRange(vector<int>& nums, int target) {
        vector<int> res = {-1, -1};
        if (nums.empty()) return res;
        
        res[0] = findFirst(nums, target);
        res[1] = findLast(nums, target);
        
        return res;
    }
    
private:
    int findFirst(const vector<int>& nums, int target) {
        int left = 0, right = nums.size() - 1;
        int ans = -1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (nums[mid] >= target) {
                right = mid - 1;
                if (nums[mid] == target) ans = mid;
            } else {
                left = mid + 1;
            }
        }
        return ans;
    }
    
    int findLast(const vector<int>& nums, int target) {
        int left = 0, right = nums.size() - 1;
        int ans = -1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (nums[mid] <= target) {
                left = mid + 1;
                if (nums[mid] == target) ans = mid;
            } else {
                right = mid - 1;
            }
        }
        return ans;
    }
};

int main() {
    // Test cases
    vector<int> nums = {5,7,7,8,8,10};
    int target = 8;
    
    Solution sol;
    vector<int> result = sol.searchRange(nums, target);
    
    cout << "[" << result[0] << ", " << result[1] << "]" << endl;
    
    return 0;
}