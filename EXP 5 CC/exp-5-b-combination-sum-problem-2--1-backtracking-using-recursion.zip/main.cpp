#include <bits/stdc++.h>
using namespace std;

class Solution {
public:
    void backtrack(vector<int>& candidates, int start,
                   vector<int>& current, int remaining,
                   vector<vector<int>>& result) {

        // Base case: target reached
        if (remaining == 0) {
            result.push_back(current);
            return;
        }

        // Try candidates from start index
        for (int i = start; i < candidates.size(); i++) {

            // Pruning
            if (candidates[i] > remaining)
                continue;

            // Choose
            current.push_back(candidates[i]);

            // Same index i allows reuse
            backtrack(candidates, i, current,
                      remaining - candidates[i], result);

            // Undo choice
            current.pop_back();
        }
    }

    vector<vector<int>> combinationSum(vector<int>& candidates,
                                       int target) {
        vector<vector<int>> result;
        vector<int> current;

        backtrack(candidates, 0, current, target, result);

        return result;
    }
};

int main() {
    Solution s;

    vector<int> candidates = {2, 3, 6, 7};
    int target = 7;

    vector<vector<int>> result =
        s.combinationSum(candidates, target);

    cout << "Combinations:\n";

    for (auto combination : result) {
        cout << "[";
        for (int i = 0; i < combination.size(); i++) {
            cout << combination[i];
            if (i < combination.size() - 1)
                cout << ",";
        }
        cout << "]\n";
    }

    return 0;
}