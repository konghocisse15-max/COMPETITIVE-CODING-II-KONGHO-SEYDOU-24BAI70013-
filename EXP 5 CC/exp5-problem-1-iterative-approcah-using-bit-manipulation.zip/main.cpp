#include <iostream>
#include <vector>
using namespace std;

class Solution {
public:
    vector<vector<int>> subsets(vector<int>& nums) {
        vector<vector<int>> result;

        int n = nums.size();

        for (int k = 0; k < (1 << n); k++) {
            vector<int> subset;

            for (int i = 0; i < n; i++) {
                if (k & (1 << i)) {
                    subset.push_back(nums[i]);
                }
            }

            result.push_back(subset);
        }

        return result;
    }
};

int main() {

    Solution s;

    vector<int> nums = {1, 2, 3};

    vector<vector<int>> result = s.subsets(nums);

    for (auto subset : result) {
        cout << "[";
        
        for (int x : subset) {
            cout << x << " ";
        }
        
        cout << "]" << endl;
    }

    return 0;
}