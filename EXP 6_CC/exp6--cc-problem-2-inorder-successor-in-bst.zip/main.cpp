
#include <iostream>
using namespace std;

struct TreeNode {
    int val;
    TreeNode* left;
    TreeNode* right;

    TreeNode(int x) {
        val = x;
        left = nullptr;
        right = nullptr;
    }
};

class Solution {
public:
    TreeNode* inorderSuccessor(TreeNode* root, TreeNode* p) {
        TreeNode* successor = nullptr;

        while (root != nullptr) {
            if (p->val >= root->val) {
                root = root->right;
            } else {
                successor = root;
                root = root->left;
            }
        }

        return successor;
    }
};

int main() {
    // Create the BST: [5, 3, 6, 2, 4]
    TreeNode* root = new TreeNode(5);
    root->left = new TreeNode(3);
    root->right = new TreeNode(6);
    root->left->left = new TreeNode(2);
    root->left->right = new TreeNode(4);

    // Find successor of node 3
    TreeNode* p = root->left;

    Solution sol;
    TreeNode* result = sol.inorderSuccessor(root, p);

    if (result != nullptr) {
        cout << "Inorder Successor: " << result->val << endl;
    } else {
        cout << "Inorder Successor: NULL" << endl;
    }

    return 0;
}