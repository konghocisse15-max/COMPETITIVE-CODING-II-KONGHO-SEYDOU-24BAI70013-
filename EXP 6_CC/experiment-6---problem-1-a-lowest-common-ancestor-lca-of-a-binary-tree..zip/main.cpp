#include <iostream>
using namespace std;

struct TreeNode {
    int val;
    TreeNode* left;
    TreeNode* right;

    TreeNode(int x) {
        val = x;
        left = nullptr;
        right = nullptr;
    }
};

TreeNode* lowestCommonAncestor(TreeNode* root, TreeNode* p, TreeNode* q) {

    // Base case
    if (root == nullptr || root == p || root == q) {
        return root;
    }

    // Search in left subtree
    TreeNode* left = lowestCommonAncestor(root->left, p, q);

    // Search in right subtree
    TreeNode* right = lowestCommonAncestor(root->right, p, q);

    // If p and q are found in different subtrees
    if (left != nullptr && right != nullptr) {
        return root;
    }

    // Return whichever side contains p or q
    if (left != nullptr) {
        return left;
    }

    return right;
}

int main() {

    // Create the binary tree
    TreeNode* root = new TreeNode(3);

    root->left = new TreeNode(5);
    root->right = new TreeNode(1);

    root->left->left = new TreeNode(6);
    root->left->right = new TreeNode(2);

    root->right->left = new TreeNode(0);
    root->right->right = new TreeNode(8);

    root->left->right->left = new TreeNode(7);
    root->left->right->right = new TreeNode(4);

    // Select p and q
    TreeNode* p = root->left;                    // 5
    TreeNode* q = root->right;                   // 1

    // Find LCA
    TreeNode* result = lowestCommonAncestor(root, p, q);

    cout << "Lowest Common Ancestor of "
         << p->val << " and "
         << q->val << " is: "
         << result->val << endl;

    return 0;
}