#include <iostream>
#include <vector>

using namespace std;

class Solution {
public:
    vector<int> productExceptSelf(vector<int>& nums) {
        int n = nums.size();
        vector<int> result(n, 1);

        // Pass 1: Compute Prefix Products
        int prefixProduct = 1;
        for (int i = 0; i < n; i++) {
            cout << "[DEBUG] Processing index " << i << ". Current prefix=" << prefixProduct << endl;
            result[i] = prefixProduct;
            prefixProduct *= nums[i];
        }

        //  Multiply by Suffix Products
        int suffixProduct = 1;
        cout << "[DEBUG] Starting backward pass..." << endl;
        for (int i = n - 1; i >= 0; i--) {
            cout << "[DEBUG] Backward index " << i << ". Current suffix=" << suffixProduct << ", Result before mult=" << result[i] << endl;
            result[i] *= suffixProduct;
            suffixProduct *= nums[i];
        }

        return result;
    }
};

int main() {
    
    vector<int> nums = {8, 10, 12, 14};

    cout << "Input: [8, 10, 12, 14]" << endl;
    
    Solution sol;
    vector<int> output = sol.productExceptSelf(nums);

    cout << "Output: [";
    for (int i = 0; i < output.size(); ++i) {
        cout << output[i] << (i == output.size() - 1 ? "" : ", ");
    }
    cout << "]" << endl;

    return 0;
}