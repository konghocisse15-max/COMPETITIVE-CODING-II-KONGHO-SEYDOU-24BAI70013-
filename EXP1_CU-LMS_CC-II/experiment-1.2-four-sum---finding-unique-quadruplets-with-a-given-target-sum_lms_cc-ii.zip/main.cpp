#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

vector<vector<int>> fourSum(vector<int>& nums, int target) {
    vector<vector<int>> result;

    // Sort the array
    sort(nums.begin(), nums.end());

    int n = nums.size();

    for (int i = 0; i < n - 3; i++) {

        // Skip duplicate values for i
        if (i > 0 && nums[i] == nums[i - 1])
            continue;

        for (int j = i + 1; j < n - 2; j++) {

            // Skip duplicate values for j
            if (j > i + 1 && nums[j] == nums[j - 1])
                continue;

            int left = j + 1;
            int right = n - 1;

            while (left < right) {

                long long sum = (long long)nums[i]
                              + nums[j]
                              + nums[left]
                              + nums[right];

                if (sum == target) {

                    result.push_back({
                        nums[i],
                        nums[j],
                        nums[left],
                        nums[right]
                    });

                    // Skip duplicate left values
                    while (left < right &&
                           nums[left] == nums[left + 1])
                        left++;

                    // Skip duplicate right values
                    while (left < right &&
                           nums[right] == nums[right - 1])
                        right--;

                    left++;
                    right--;
                }

                else if (sum < target) {
                    left++;
                }

                else {
                    right--;
                }
            }
        }
    }

    return result;
}

int main() {
    int n, target;

    // Number of elements
    cin >> n;

    // Create vector with n elements
    vector<int> nums(n);

    // Input array elements
    for (int i = 0; i < n; i++)
        cin >> nums[i];

    // Input target
    cin >> target;

    // Find quadruplets
    vector<vector<int>> result = fourSum(nums, target);

    // Display result
    for (auto quad : result) {
        for (int num : quad)
            cout << num << " ";

        cout << endl;
    }

    return 0;
}