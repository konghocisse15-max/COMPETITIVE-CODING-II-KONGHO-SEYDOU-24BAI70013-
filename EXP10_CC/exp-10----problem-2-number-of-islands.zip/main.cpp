#include <iostream>
#include <vector>
using namespace std;

void dfs(vector<vector<char>>& grid, int r, int c, int m, int n) {
    // Check boundaries and water
    if (r < 0 || r >= m || c < 0 || c >= n || grid[r][c] != '1')
        return;

    // Mark land as visited
    grid[r][c] = '0';

    // Visit four directions
    dfs(grid, r - 1, c, m, n); // Up
    dfs(grid, r + 1, c, m, n); // Down
    dfs(grid, r, c - 1, m, n); // Left
    dfs(grid, r, c + 1, m, n); // Right
}

int numIslands(vector<vector<char>>& grid) {
    int m = grid.size();
    int n = grid[0].size();
    int count = 0;

    for (int r = 0; r < m; r++) {
        for (int c = 0; c < n; c++) {

            if (grid[r][c] == '1') {
                count++;
                dfs(grid, r, c, m, n);
            }
        }
    }

    return count;
}

int main() {
    int m, n;

    cout << "Enter number of rows: ";
    cin >> m;

    cout << "Enter number of columns: ";
    cin >> n;

    vector<vector<char>> grid(m, vector<char>(n));

    cout << "Enter grid (0 for water, 1 for land):\n";

    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            cin >> grid[i][j];
        }
    }

    int result = numIslands(grid);

    cout << "Number of islands: " << result << endl;

    return 0;
}